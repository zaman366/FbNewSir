package com.team.ghana.enums;

public enum ContractType {
    UNISYSTEMS, EXTERNAL
}
