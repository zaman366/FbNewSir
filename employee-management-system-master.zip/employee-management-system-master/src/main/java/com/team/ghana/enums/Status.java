package com.team.ghana.enums;

public enum Status {
    ACTIVE,INACTIVE
}
