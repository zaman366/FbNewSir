package com.team.ghana.enums;

public enum TaskStatus {
    NEW, STARTED, DONE
}
