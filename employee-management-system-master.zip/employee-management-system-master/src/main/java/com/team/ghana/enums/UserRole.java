package com.team.ghana.enums;

public enum UserRole {
    ADMIN, BUSINESSUNITMANAGER, DEPARTMENTMANAGER, UNITMANAGER, USER
}
